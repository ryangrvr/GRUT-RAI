from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Dict, Any, Literal, Optional

from core.constants import GRUTParams
from core.schemas import EngineInput, EngineOutput
from core.engine import run_engine
from rai.respond import craft_narrative

app = FastAPI(title="GRUT-RAI Sovereign API", version="0.1.0")

PARAMS = GRUTParams()

class AskRequest(BaseModel):
    text: str = Field(..., description="User prompt")
    mode: Literal["casual","power"] = "casual"
    engine_input: Optional[EngineInput] = None

class AskResponse(BaseModel):
    answer: Dict[str, Any]
    expandable: Dict[str, Any]
    run_id: str
    engine_version: str
    params_hash: str

@app.get("/health")
def health():
    return {"ok": True, "engine_version": PARAMS.version, "params_hash": PARAMS.params_hash}

@app.post("/runs", response_model=EngineOutput)
def runs(inp: EngineInput):
    out = run_engine(inp, PARAMS)
    return out

@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    # If no explicit engine input, use a safe default grid.
    inp = req.engine_input or EngineInput(z=[0.0, 0.5, 1.0, 2.0, 2.5])
    out = run_engine(inp, PARAMS)
    narrative = craft_narrative(req.text, out)

    # Expandable sections: equations + outputs + NIS
    sections = [
        {
            "label": "Key equations used (this run)",
            "content_markdown": (
                "Phase bridge:  S_phase(z) = 1 / (1 + exp((ln(1+z)-x0)/w))\n"
                "Tau scaling:   tau_eff(z) = tau0 * TAU_FACTOR * (H0/H(z))^p\n"
                "Stiff cap:     L_stiff(chi)=1+((gmax-1)*chi)/(chi+sigma), chi=rho/rho_lock\n"
                "Dissipation:   D = k*(eps_t/tau0)*Phi(z),  E_obs = E_base*(1-D)\n"
                "Growth proxy:  Omega_eff(z)=Ob(1+z)^3/(Ob(1+z)^3+0.7), f=Omega_eff^gamma, fσ8=σ8_0*f"
            ),
        },
        {"label": "Engine outputs", "engine": {k: out[k] for k in ["z","G_eff_over_G","f_sigma8","S_phase","tau_eff_myr","D","E_obs"]}},
        {"label": "Convergence Certificate (NIS)", "nis": out["nis"]},
    ]

    # run_id can be a hash of (params_hash + input)
    run_id = f"{out['params_hash']}-{abs(hash(str(inp.model_dump())))%10**8:08d}"

    if req.mode == "power":
        answer = {"text": narrative, "mode": "power"}
        expandable = {"title": "Show logic (engine + certificate)", "sections": sections}
    else:
        # casual mode: same content, but UI will render expandable collapsed by default
        answer = {"text": narrative, "mode": "casual"}
        expandable = {"title": "Show logic (engine + certificate)", "sections": sections}

    return {
        "answer": answer,
        "expandable": expandable,
        "run_id": run_id,
        "engine_version": out["engine_version"],
        "params_hash": out["params_hash"],
    }
