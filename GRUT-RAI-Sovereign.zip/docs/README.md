# GRUT-RAI Sovereign Foundation

This is a clean, standalone **FastAPI-first** foundation that canonizes:

- One parameter manifest (`GRUTParams`) as the single source of truth
- One deterministic engine pipeline (`run_engine`)
- One audit trail (NIS / Convergence Certificate)
- One API with **narrative-first + expandable logic** UX

## Run locally

```bash
pip install -r requirements.txt
uvicorn api.main:app --reload
```

Then open:

- `GET /health`
- `POST /ask`
- `POST /runs`
