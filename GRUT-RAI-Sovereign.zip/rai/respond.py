from __future__ import annotations

from typing import Dict, Any

def craft_narrative(user_text: str, engine_out: Dict[str, Any]) -> str:
    """Deterministic narrative layer (placeholder for future LLM).

    The goal is to be *transparent*: it narrates the operator chain and points
    to the expandable logic panel for raw numbers.
    """
    nis = engine_out["nis"]
    status = nis["status"]
    fuzz = nis["fuzz_fraction"]
    cap = nis["cap_engaged_frac"]
    Dmax = nis["D_max"]

    # "42" style: explain the why, not just the number.
    # For now we keep it short and honest.
    lines = []
    lines.append("Here’s the answer in GRUT-RAI terms, with the reasoning path preserved.")
    lines.append(f"- Numerical Integrity Standard: **{status}** (fuzz_fraction={fuzz:.4f}, D_max={Dmax:.3f}, cap_engaged={cap:.2%}).")
    lines.append("- The engine applies: memory window → H(z)-scaled τ_eff(z) → phase-bridge (Boethian pivot) → stiffness soft-cap → dissipation → growth outputs.")
    if "42" in user_text:
        lines.append("If you asked about **42**: in this system, '42' is a stand-in for *a fully auditable answer*. The meaning is not mystical—it's the traceable chain from inputs → operators → outputs.")
    else:
        lines.append("Open **Show logic** to see the exact equations used and the raw engine arrays for verification.")
    return "\n".join(lines)
