from core.constants import GRUTParams
from core.engine import run_engine
from core.schemas import EngineInput

def test_smoke_run():
    p = GRUTParams()
    out = run_engine(EngineInput(z=[0.0, 0.5, 1.0, 2.0]), p)
    assert out["nis"]["status"] in ("PASS","WARN","FAIL")
    assert len(out["z"]) == 4
    assert all(0.0 <= s <= 1.0 for s in out["S_phase"])
