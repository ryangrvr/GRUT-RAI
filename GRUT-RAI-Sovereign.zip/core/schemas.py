from __future__ import annotations

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, Literal

class EngineInput(BaseModel):
    z: List[float] = Field(..., description="Redshift grid")
    rho: Optional[List[float]] = Field(None, description="Baryonic stress proxy, same length as z or scalar list of len 1")
    v: Optional[List[float]] = Field(None, description="Peculiar velocity proxy, same length as z or scalar list of len 1")

    # Optional run controls
    eps_t_myr: Optional[float] = Field(None, description="Emergent fuzz diagnostic (Myr). If omitted, inferred from grid spacing.")
    hz_model: Literal["grut_baryonic_plus_geometric", "lcdm_flat"] = "grut_baryonic_plus_geometric"

class NISReport(BaseModel):
    status: Literal["PASS","WARN","FAIL"]
    eps_t_myr: float
    fuzz_fraction: float
    phase_alignment: Optional[float] = None
    cap_engaged_frac: float
    D_max: float
    notes: List[str] = []

class EngineOutput(BaseModel):
    engine_version: str
    params_hash: str

    # Key arrays
    z: List[float]
    S_phase: List[float]
    tau_eff_myr: List[float]
    g_raw: List[float]
    g_cap: List[float]
    G_eff_over_G: List[float]

    # Growth products
    omega_eff: List[float]
    f_growth: List[float]
    f_sigma8: List[float]

    # Dissipation / elasticity
    D: List[float]
    E_obs: List[float]

    # Audits
    nis: NISReport

    # Additional metadata for UI
    meta: Dict[str, Any] = {}
