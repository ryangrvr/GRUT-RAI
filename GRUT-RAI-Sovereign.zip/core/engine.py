from __future__ import annotations

import numpy as np
from .constants import GRUTParams
from .operators import phase_sigmoid, stiff_cap_gain, smooth_min, dissipation_phi, dissipation_factor, tau_eff_from_Hz
from .hz_models import H_grut_baryonic_plus_geometric, H_lcdm_flat
from .nis import infer_eps_t_myr_from_zgrid, nis_status

def omega_eff(z: np.ndarray, omega_b: float, geometric_term: float = 0.7) -> np.ndarray:
    """Effective density proxy used in earlier GRUT growth discussions."""
    num = omega_b * (1 + z) ** 3
    return num / (num + geometric_term)

def compute_growth_products(z: np.ndarray, p: GRUTParams) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    Om_eff = omega_eff(z, p.omega_b, p.geometric_DE)
    f = Om_eff ** p.gamma_growth
    fs8 = p.sigma8_0 * f
    return Om_eff, f, fs8

def run_engine(inp, p: GRUTParams) -> dict:
    """Run the sovereign GRUT engine pipeline (minimal coherent implementation).

    Notes:
      - This does NOT yet implement full time-convolution memory integration.
        It implements the hardened operator stack with explicit regime + caps + dissipation.
      - The kernel-integrator from the legacy repo can be plugged into `g_raw` later.
    """
    z = np.asarray(inp.z, dtype=np.float64)
    z = np.clip(z, 0.0, None)

    # broadcast rho and v
    if inp.rho is None:
        rho = np.ones_like(z)
    else:
        r = np.asarray(inp.rho, dtype=np.float64)
        rho = np.full_like(z, float(r[0])) if r.size == 1 else r
    if inp.v is None:
        v = np.zeros_like(z)
    else:
        vv = np.asarray(inp.v, dtype=np.float64)
        v = np.full_like(z, float(vv[0])) if vv.size == 1 else vv

    # 1) phase bridge
    S = phase_sigmoid(z, p.phase_x0, p.phase_w)

    # 2) H(z) provider
    H0 = 70.0
    if inp.hz_model == "lcdm_flat":
        Hz = H_lcdm_flat(z, H0=H0)
        hz_label = "lcdm_flat"
    else:
        Hz = H_grut_baryonic_plus_geometric(z, p, H0=H0)
        hz_label = "grut_baryonic_plus_geometric"

    # 3) tau_eff scaling
    tau_eff = tau_eff_from_Hz(p.tau0_myr, p.tau_factor, H0, Hz, p.tau_p)

    # 4) raw gain model (placeholder)
    # IR gain approaches 1+alpha_imp = 4/3 when S->1
    g_raw = 1.0 + p.alpha_imp * S

    # 5) stiffness soft cap
    chi = np.clip(rho / p.rho_lock, 0.0, None)
    L = stiff_cap_gain(chi, p.g_max, p.cap_sigma)
    g_cap = smooth_min(g_raw, L, softness=1e-3)

    # 6) dissipation
    eps_t = float(inp.eps_t_myr) if inp.eps_t_myr is not None else infer_eps_t_myr_from_zgrid(z, p.tau0_myr)
    phi = dissipation_phi(z, S, p.dissipation_phi_mode)
    D, fuzz_fraction = dissipation_factor(eps_t, p.tau0_myr, p.dissipation_k, phi)
    # bound D for numerical sanity (still reported & audited)
    D = np.clip(D, 0.0, 0.999)
    E_obs = p.E_base * (1.0 - D)

    # 7) growth products (legacy GRUT proxy)
    Om_eff, f, fs8 = compute_growth_products(z, p)

    # 8) NIS report
    cap_engaged = float(np.mean(g_raw > L))
    D_max = float(np.max(D))
    status, notes = nis_status(float(fuzz_fraction), D_max)

    out = dict(
        engine_version=p.version,
        params_hash=p.params_hash,
        z=z.tolist(),
        S_phase=S.tolist(),
        tau_eff_myr=tau_eff.tolist(),
        g_raw=g_raw.tolist(),
        g_cap=g_cap.tolist(),
        G_eff_over_G=g_cap.tolist(),
        omega_eff=Om_eff.tolist(),
        f_growth=f.tolist(),
        f_sigma8=fs8.tolist(),
        D=D.tolist(),
        E_obs=E_obs.tolist(),
        nis=dict(
            status=status,
            eps_t_myr=float(eps_t),
            fuzz_fraction=float(fuzz_fraction),
            phase_alignment=None,
            cap_engaged_frac=cap_engaged,
            D_max=D_max,
            notes=notes + [f"hz_model={hz_label}", f"tau_eff(z)=tau0*TAU_FACTOR*(H0/H(z))^p with p={p.tau_p}"],
        ),
        meta=dict(
            hz_model=hz_label,
            H0=H0,
            tau0_myr=p.tau0_myr,
            lambda_lock=p.lambda_lock,
            K0_anchor=p.K0_anchor,
        )
    )
    return out
