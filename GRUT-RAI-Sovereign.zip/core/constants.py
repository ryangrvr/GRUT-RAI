from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
import math

def _stable_hash(obj: dict) -> str:
    # Deterministic hash of params for reproducibility.
    blob = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:16]

@dataclass(frozen=True)
class GRUTParams:
    """Canonical parameter manifest (single source of truth).

    Naming avoids historical symbol collisions:
      - K0_anchor: curvature floor (-1/12)
      - alpha_imp: impedance/memory headroom (1/3) so IR gain -> 4/3
      - E_base: elasticity floor (0.75) before dissipation
    """

    version: str = "grut-rai-2026.1"

    # Geometric invariants
    lambda_lock: float = 2.0 / math.sqrt(3.0)          # ≈ 1.154700538...
    K0_anchor: float = -1.0 / 12.0                     # curvature floor
    alpha_imp: float = 1.0 / 3.0                       # IR headroom (-> 4/3 gain)

    # Memory window
    tau0_myr: float = 41.9                             # Myr (display-friendly)
    # Elasticity
    E_base: float = 0.75                               # theoretical stiffness ceiling (pre-dissipation)

    # Saturation / back-reaction
    g_max: float = 4.0 / 3.0                           # ceiling for G_eff/G
    rho_lock: float = 1.0                              # normalization for chi=rho/rho_lock (provisional)
    cap_sigma: float = 0.1                             # softness in L_stiff(chi)

    # Regime bridge (Boethian pivot)
    phase_x0: float = 0.0                              # x0 in x=ln(1+z); 0 => z0=0
    phase_w: float = 0.25                              # width; larger = smoother

    # Dissipation
    dissipation_k: float = 20.0                        # maps fuzz_fraction -> D (provisional)
    dissipation_phi_mode: str = "S_phase"              # "S_phase" | "one_minus_S" | "flat"

    # Growth (defaults reflect your earlier calibration notes)
    omega_b: float = 0.0486
    gamma_growth: float = 0.61
    sigma8_0: float = 0.936                            # GRUT amplitude (Planck*sqrt(4/3))
    geometric_DE: float = 0.7                          # placeholder "geometric response" term used in older GRUT notes

    # Hz scaling for tau_eff
    tau_factor: float = 1.0
    tau_p: float = 1.0

    def as_dict(self) -> dict:
        return asdict(self)

    @property
    def params_hash(self) -> str:
        return _stable_hash(self.as_dict())
