from __future__ import annotations

import numpy as np
from .constants import GRUTParams

def phase_sigmoid(z: np.ndarray, x0: float, w: float) -> np.ndarray:
    """Sigmoid regime bridge S_phase(z) using x = ln(1+z)."""
    x = np.log1p(z)
    return 1.0 / (1.0 + np.exp((x - x0) / w))

def stiff_cap_gain(chi: np.ndarray, gmax: float, sigma: float) -> np.ndarray:
    """Rational soft-cap for anti-singularity back-reaction."""
    return 1.0 + (gmax - 1.0) * (chi / (chi + sigma))

def smooth_min(a: np.ndarray, b: np.ndarray, softness: float = 1e-3) -> np.ndarray:
    """Smooth approximation to min(a,b) using log-sum-exp."""
    s = max(float(softness), 1e-12)
    return -s * np.log(np.exp(-a / s) + np.exp(-b / s))

def dissipation_phi(z: np.ndarray, S_phase: np.ndarray, mode: str) -> np.ndarray:
    if mode == "S_phase":
        return S_phase
    if mode == "one_minus_S":
        return 1.0 - S_phase
    return np.ones_like(z)

def dissipation_factor(eps_t_myr: float, tau0_myr: float, k: float, phi_z: np.ndarray) -> tuple[np.ndarray, float]:
    fuzz_fraction = float(eps_t_myr) / float(tau0_myr)
    D = k * fuzz_fraction * phi_z
    return D, fuzz_fraction

def tau_eff_from_Hz(tau0_myr: float, tau_factor: float, H0: float, Hz: np.ndarray, p: float) -> np.ndarray:
    """Canonical implementation: tau_eff(z)=tau0*TAU_FACTOR*(H0/H(z))^p"""
    return tau0_myr * tau_factor * (H0 / Hz) ** p
