from __future__ import annotations
import numpy as np
from .constants import GRUTParams

def H_lcdm_flat(z: np.ndarray, H0: float = 70.0, omega_m: float = 0.3, omega_l: float = 0.7) -> np.ndarray:
    """Flat LCDM baseline H(z)."""
    return H0 * np.sqrt(omega_m * (1 + z) ** 3 + omega_l)

def H_grut_baryonic_plus_geometric(z: np.ndarray, p: GRUTParams, H0: float = 70.0) -> np.ndarray:
    """Legacy GRUT-style background: baryons + geometric response term.

    NOTE: This is an implementation baseline used for tau_eff scaling.
    It is recorded in NIS metadata so future versions can swap models cleanly.
    """
    enhanced_matter = p.omega_b * (1 + z) ** 3
    return H0 * np.sqrt(enhanced_matter + p.geometric_DE)
