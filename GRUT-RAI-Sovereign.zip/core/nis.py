from __future__ import annotations

import numpy as np

def infer_eps_t_myr_from_zgrid(z: np.ndarray, tau0_myr: float) -> float:
    """Infer an eps_t proxy from grid spacing.

    This is a *placeholder* until you wire phase-error-based inference.
    We choose a conservative mapping:
      eps_t_myr = max(0.05, min(0.5, median_delta_z * tau0_myr))
    """
    if z.size < 2:
        return 0.1
    dz = np.diff(np.sort(z))
    med = float(np.median(np.abs(dz)))
    eps = med * float(tau0_myr)
    return float(np.clip(eps, 0.05, 0.5))

def nis_status(fuzz_fraction: float, D_max: float) -> tuple[str, list[str]]:
    notes=[]
    status="PASS"
    if fuzz_fraction > 0.01:
        status="WARN"
        notes.append(f"fuzz_fraction {fuzz_fraction:.4f} exceeds 1% target")
    if fuzz_fraction > 0.02:
        status="FAIL"
        notes.append(f"fuzz_fraction {fuzz_fraction:.4f} exceeds 2% hard limit")
    if D_max > 0.1:
        status="WARN" if status=="PASS" else status
        notes.append(f"dissipation D_max {D_max:.3f} exceeds 0.1 threshold")
    if D_max > 0.2:
        status="FAIL"
        notes.append(f"dissipation D_max {D_max:.3f} exceeds 0.2 hard limit")
    return status, notes
